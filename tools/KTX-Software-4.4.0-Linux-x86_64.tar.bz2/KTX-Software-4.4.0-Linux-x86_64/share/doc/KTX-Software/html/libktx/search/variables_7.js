var searchData=
[
  ['generatemipmaps_555',['generateMipmaps',['../structktxTexture.html#a4159f859437a820d7984beda366e2eaa',1,'ktxTexture::generateMipmaps()'],['../structktxTextureCreateInfo.html#a9c26601222e6a037f7dbae7b61b18fd0',1,'ktxTextureCreateInfo::generateMipmaps()']]],
  ['getpos_556',['getpos',['../structktxStream.html#adcabf99e783fe9ca551ac9706372400c',1,'ktxStream']]],
  ['getsize_557',['getsize',['../structktxStream.html#a76bd679ca3d583cc56c524e53665e775',1,'ktxStream']]],
  ['glbaseinternalformat_558',['glBaseInternalformat',['../structktxTexture1.html#aaadefe13bf76c26cb921afa52fb29192',1,'ktxTexture1']]],
  ['glformat_559',['glFormat',['../structktxTexture1.html#a05fa4fecc2735f68d34651a62493ecd9',1,'ktxTexture1']]],
  ['glinternalformat_560',['glInternalformat',['../structktxTexture1.html#a1318d73f800ff61d045b740331939596',1,'ktxTexture1::glInternalformat()'],['../structktxTextureCreateInfo.html#a1318d73f800ff61d045b740331939596',1,'ktxTextureCreateInfo::glInternalformat()']]],
  ['gltype_561',['glType',['../structktxTexture1.html#ac8a870c675f1e36c456c9de2e3ac9855',1,'ktxTexture1']]]
];
